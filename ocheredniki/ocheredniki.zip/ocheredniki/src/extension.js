"use strict";
// ЭТОТ ФАЙЛ КОПИРУЕТСЯ ВНУТРЬ НОВОГО ПЛАГИНА (runtime, src/runtime_ts)
// Он не знает заранее, что он "Очередники". Он читает app_config.json.
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.activate = activate;
const vscode = __importStar(require("vscode"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
// Хак для импорта JSON в TS (файл появляется только в сгенерированном плагине)
// @ts-ignore
const appData = require('./app_config.json');
// Хранилище данных (теперь с поддержкой персистентности)
let STATE = {};
let STORAGE_PATH = null; // Путь к файлу БД 
let IS_WORKSPACE_OPEN = false;
// Хранилище активных панелей (Singleton pattern)
const PANELS = {};
function activate(context) {
    console.log('Runtime активирован для:', appData.title);
    // 1. Инициализация рабочей среды
    if (vscode.workspace.workspaceFolders && vscode.workspace.workspaceFolders.length > 0) {
        IS_WORKSPACE_OPEN = true;
        const rootPath = vscode.workspace.workspaceFolders[0].uri.fsPath;
        const dataPath = path.join(rootPath, 'data');
        if (!fs.existsSync(dataPath)) {
            try {
                fs.mkdirSync(dataPath);
            }
            catch (e) {
                console.error('Error creating data dir:', e);
            }
        }
        STORAGE_PATH = path.join(dataPath, 'db.json');
        // Загрузка данных
        if (fs.existsSync(STORAGE_PATH)) {
            try {
                const raw = fs.readFileSync(STORAGE_PATH, 'utf-8');
                STATE = JSON.parse(raw);
            }
            catch (e) {
                console.error('Failed to load state:', e);
            }
        }
    }
    else {
        console.warn('No workspace open. State will be in-memory only.');
        IS_WORKSPACE_OPEN = false;
    }
    // 2. Регистрация команд
    // Команда открытия конкретного объекта (из Sidebar)
    const openObjectCmd = vscode.commands.registerCommand(appData.id + '.openObject', (objectId) => {
        if (!IS_WORKSPACE_OPEN) {
            vscode.window.showWarningMessage('Пожалуйста, откройте папку проекта (File -> Open Folder), чтобы сохранять данные.');
            return;
        }
        openWebview(context, objectId);
    });
    // Команда запуска (из Command Palette) - открываем первый объект или дашборд
    const startCmd = vscode.commands.registerCommand(appData.id + '.start', () => {
        if (!IS_WORKSPACE_OPEN) {
            vscode.window.showWarningMessage('Пожалуйста, откройте папку проекта (File -> Open Folder), чтобы сохранять данные.');
            return;
        }
        // По умолчанию открываем первый объект
        const firstObjectId = Object.keys(appData.objects)[0];
        if (firstObjectId) {
            openWebview(context, firstObjectId);
        }
        else {
            vscode.window.showInformationMessage('В приложении нет объектов.');
        }
    });
    // Команда открытия документации (README)
    const docsCmd = vscode.commands.registerCommand(appData.id + '.openDocs', () => {
        const readmePath = path.join(context.extensionPath, 'README.md');
        if (fs.existsSync(readmePath)) {
            const uri = vscode.Uri.file(readmePath);
            vscode.commands.executeCommand('markdown.showPreview', uri);
        }
        else {
            vscode.window.showErrorMessage('Файл документации не найден.');
        }
    });
    // Команда открытия Руководства пользователя (USER_MANUAL)
    const userManualCmd = vscode.commands.registerCommand(appData.id + '.openUserManual', () => {
        const manualPath = path.join(context.extensionPath, 'USER_MANUAL.md');
        if (fs.existsSync(manualPath)) {
            const uri = vscode.Uri.file(manualPath);
            vscode.commands.executeCommand('markdown.showPreview', uri);
        }
        else {
            vscode.window.showErrorMessage('Файл USER_MANUAL.md не найден.');
        }
    });
    // Команда открытия папки
    const openWsCmd = vscode.commands.registerCommand(appData.id + '.openWorkspace', () => {
        vscode.commands.executeCommand('vscode.openFolder');
    });
    context.subscriptions.push(startCmd, openObjectCmd, docsCmd, userManualCmd, openWsCmd);
    // 3. Инициализация Сайдбара (Tree View)
    const treeProvider = new KreatorTreeProvider();
    vscode.window.registerTreeDataProvider(appData.id + '.mainView', treeProvider);
}
// --- Бизнес-логика UI (Webview) ---
function openWebview(context, objectId) {
    // 1. Singleton Check: Если панель уже открыта, просто фокусимся на ней
    if (PANELS[objectId]) {
        PANELS[objectId].reveal(vscode.ViewColumn.One);
        return;
    }
    const objectConfig = appData.objects[objectId];
    if (!objectConfig)
        return;
    // 2. Создаем новую панель
    const panel = vscode.window.createWebviewPanel('kreatorApp-' + objectId, // ID view type
    objectConfig.config.label || objectId, // Title
    vscode.ViewColumn.One, { enableScripts: true });
    // Запоминаем objectId в самой панели для удобства
    panel.kreatorObjectId = objectId;
    // Сохраняем в реестр
    PANELS[objectId] = panel;
    // Рендерим контент
    updateWebview(panel, objectId);
    // Подписка на сообщения от WebView
    panel.webview.onDidReceiveMessage((message) => {
        handleMessage(message, panel);
    }, undefined, context.subscriptions);
    // Очистка при закрытии
    panel.onDidDispose(() => {
        delete PANELS[objectId];
        panel.dispose();
    }, null, context.subscriptions);
}
function getHtmlContent(objectId) {
    const objectConfig = appData.objects[objectId];
    if (!STATE[objectId])
        STATE[objectId] = [];
    // Рендерим ТОЛЬКО запрошенный объект
    let bodyContent = '';
    switch (objectConfig.type) {
        case 'LIST':
            bodyContent = renderList(objectId, objectConfig.config, STATE[objectId]);
            break;
        default:
            bodyContent = `<div>Неизвестный тип объекта: ${objectConfig.type}</div>`;
    }
    return `<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: sans-serif; padding: 20px; }
            .object-container { padding: 10px; }
            h2 { color: #007acc; border-bottom: 2px solid #ccc; padding-bottom: 5px; }
            ul { list-style-type: none; padding: 0; }
            li { background: #f3f3f3; margin: 5px 0; padding: 10px; display: flex; justify-content: space-between; color: black; align-items: center; border-radius: 4px; }
            button { cursor: pointer; padding: 6px 12px; border: none; background: #007acc; color: white; border-radius: 3px; }
            button:hover { background: #005f9e; }
            .delete-btn { color: #d9534f; background: none; font-weight: bold; font-size: 16px; padding: 0 5px; }
            .delete-btn:hover { background: none; color: #c9302c; }
            .controls { display: flex; gap: 10px; margin-bottom: 20px; }
            input { padding: 8px; flex-grow: 1; border: 1px solid #ccc; border-radius: 3px; }
        </style>
    </head>
    <body>
        ${bodyContent}
        
        <script>
            const vscode = acquireVsCodeApi();
            
            function addItem(id) {
                const text = document.getElementById('input-' + id).value;
                if(!text) return;
                vscode.postMessage({ command: 'add', id: id, value: text });
            }

            function deleteItem(id, index) {
                vscode.postMessage({ command: 'delete', id: id, index: index });
            }
        </script>
    </body>
    </html>`;
}
function renderList(id, config, items) {
    const listItems = items.map((item, index) => `<li>
            <span>${item}</span>
            <button class="delete-btn" onclick="deleteItem('${id}', ${index})">✕</button>
         </li>`).join('');
    return `
    <div class="object-container">
        <h2>${config.label}</h2>
        <div class="controls">
            <input type="text" id="input-${id}" placeholder="Новый элемент...">
            <button onclick="addItem('${id}')">Добавить</button>
        </div>
        <ul>
            ${listItems}
        </ul>
        ${items.length === 0 ? '<p style="color: #888;">Список пуст. Добавьте первый элемент!</p>' : ''}
    </div>
    `;
}
function updateWebview(panel, objectId) {
    if (panel.webview) {
        panel.webview.html = getHtmlContent(objectId);
    }
}
function handleMessage(message, panel) {
    const objId = message.id; // Это ID объекта, с которым идет работа
    // Валидация: убедимся, что месседж пришел из панели того же объекта (защита от путаницы)
    if (objId !== panel.kreatorObjectId) {
        console.warn('Id mismatch in handleMessage');
    }
    if (message.command === 'add') {
        if (!STATE[objId])
            STATE[objId] = [];
        STATE[objId].push(message.value);
        saveState();
        updateWebview(panel, objId);
    }
    else if (message.command === 'delete') {
        if (!STATE[objId])
            return;
        STATE[objId].splice(message.index, 1);
        saveState();
        updateWebview(panel, objId);
    }
}
function saveState() {
    if (STORAGE_PATH) {
        try {
            fs.writeFileSync(STORAGE_PATH, JSON.stringify(STATE, null, 2));
        }
        catch (e) {
            console.error('Failed to save state:', e);
        }
    }
}
// --- Tree Data Provider (Sidebar) ---
class KreatorTreeProvider {
    constructor() {
        this._onDidChangeTreeData = new vscode.EventEmitter();
        this.onDidChangeTreeData = this._onDidChangeTreeData.event;
    }
    refresh() {
        this._onDidChangeTreeData.fire();
    }
    getTreeItem(element) {
        return element;
    }
    getChildren(element) {
        if (!element) {
            // Root elements
            const items = [];
            // 1. Установка и Запуск (README)
            const docItem = new vscode.TreeItem('📚 Установка и Запуск', vscode.TreeItemCollapsibleState.None);
            docItem.command = { command: appData.id + '.openDocs', title: 'Открыть' };
            items.push(docItem);
            // 1.1 Руководство пользователя (USER_MANUAL)
            const manualItem = new vscode.TreeItem('📘 Руководство пользователя', vscode.TreeItemCollapsibleState.None);
            manualItem.command = { command: appData.id + '.openUserManual', title: 'Открыть' };
            items.push(manualItem);
            // 2. Проверка Workspace
            if (!IS_WORKSPACE_OPEN) {
                const warnItem = new vscode.TreeItem('⚠️ Открыть Проект...', vscode.TreeItemCollapsibleState.None);
                warnItem.description = 'Данные недоступны';
                warnItem.command = { command: appData.id + '.openWorkspace', title: 'Открыть папку' };
                warnItem.tooltip = 'Нажмите, чтобы открыть папку для хранения базы данных.';
                items.push(warnItem);
            }
            else {
                // 3. Объекты системы
                // Выводим список объектов.
                for (const [key, obj] of Object.entries(appData.objects)) {
                    const objItem = new vscode.TreeItem(obj.config.label || key, vscode.TreeItemCollapsibleState.None);
                    objItem.iconPath = new vscode.ThemeIcon('list-flat'); // Иконка списка
                    // ВАЖНО: Вызываем специфическую команду с аргументом key
                    objItem.command = {
                        command: appData.id + '.openObject',
                        title: 'Открыть',
                        arguments: [key]
                    };
                    items.push(objItem);
                }
            }
            return Promise.resolve(items);
        }
        return Promise.resolve([]);
    }
}
